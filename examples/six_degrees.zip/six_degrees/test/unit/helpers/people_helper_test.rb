require 'test_helper'

class PeopleHelperTest < ActionView::TestCase
end
