# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '8c8e7ba1ecb9ca20d55aaabe93ef68d02d730c2c457e2b171af41d996d858b8e6b3372a54219158afe4d1755fc654fa0654162436f92f3a6542415cba9707ce2'
